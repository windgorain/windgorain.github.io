#!/bin/sh
xattr -rd com.apple.quarantine vnmesh
./vnmesh &

