运行:
sudo ./start_vnmesh_macos.sh

运行之后可以通过浏览器进行配置:
本地访问: http://localhost:8888
远程访问: http://目标IP:8888
进入后配置用户名/密码, 点击确定即可

退出进程:
访问 "系统设置 - 关闭系统"页面, 点击"关闭系统"即可
也可以直接kill vnmesh进程 

常用服务:
域名映射服务: "公网服务 - 域名映射"配置Web映射服务。
端口映射服务: "公网服务 - 端口映射"配置TCP端口映射服务。
设备映射服务: "公网服务 - 设备映射"配置全端口设备映射服务。
更多功能请参考: https://vnmesh.cn/traversal/doc/index.htm

命令行配置方式:
telnet localhost 2300

user-view>config-view
config-view>xnetc-view
xnetc-view>show this

这个视图下可以敲击 ? 查看命令帮助


