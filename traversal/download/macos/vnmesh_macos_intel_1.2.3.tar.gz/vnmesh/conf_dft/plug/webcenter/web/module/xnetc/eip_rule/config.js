function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var str = $("#rip").val();

    if (str == "") {
        str = "0.0.0.0";
    }

    var sData = "_do=cmd.run&cmd=config-view;xnetc-view;eip rule " + $("#eip").val() + " " + str;

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


