function _my_ele_enable(ele_name) {
    $("#" + ele_name + "_font").css("color", "black");
    $("#" + ele_name).css("color", "black");
    $("#" + ele_name).prop("disabled", false);
}

function _my_ele_disable(ele_name) {
    $("#" + ele_name + "_font").css("color", "#999999");
    $("#" + ele_name).css("color", "#999999");
    $("#" + ele_name).prop("disabled", true);
}

function _my_change() {
    var proto = $("#protocol").val();
    var dec_pos = $("#dec_pos").val(); 
    if (proto == "https") {
        _my_ele_enable("dec_pos");
        _my_ele_enable("http_visit");
        _my_ele_enable("ssl_visit");

        if ((dec_pos != 0) || $('#http_visit').prop("checked")) {
            _my_ele_enable("reg_auth");
            _my_ele_enable("http_auth");
            _my_ele_enable("group");
            _my_ele_enable("rewrite_host");
        } else {
            _my_ele_disable("reg_auth");
            _my_ele_disable("http_auth");
            _my_ele_disable("group");
            _my_ele_disable("rewrite_host");
        }
    } else if (proto == "http") {
        _my_ele_enable("dec_pos");
        _my_ele_enable("http_visit");
        _my_ele_enable("reg_auth");
        _my_ele_enable("http_auth");
        _my_ele_enable("group");
        _my_ele_enable("rewrite_host");
        if (dec_pos != 0) {
            _my_ele_enable("ssl_visit");
        } else {
            _my_ele_disable("ssl_visit");
        }
    } else if (proto == "mstsc") {
        _my_ele_disable("dec_pos");
        _my_ele_disable("http_visit");
        _my_ele_disable("ssl_visit");
        _my_ele_disable("reg_auth");
        _my_ele_disable("http_auth");
        _my_ele_disable("group");
        _my_ele_disable("rewrite_host");
    }

    var feature = Number(status_json.data.feature);
    if (! (feature & 0x10)) { /* 是否允许SSL访问 */
        _my_ele_disable("ssl_visit");
        _my_ele_disable("dec_pos");
    }
}

function parseHostAndPort(input) {
    const parts = input.split(':');
    
    if (parts.length > 2) {
        throw new Error('Invalid format: multiple colons found');
    }
    
    return {
        hostname: parts[0],
        port: parts[1] ? parts[1] : null
    };
}

function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var protocol = $("#protocol").val();
    var dec_pos = $("#dec_pos").val();
    var hp = parseHostAndPort($('#target').val());

    var sData = "_do=cmd.run&cmd=config-view;xnetc-view;public-service web rule " + $("#name").val();
    sData += " -t " + protocol;
    sData += " -h " + hp.hostname;
    if (hp.port) {
        sData += " -p " + hp.port;
    }

	if ($('#description').val()) {
        sData += " -d " + $('#description').val();
    }

    if ($('#reg_auth').prop("checked")) {
        sData += " -r";
    }

	if ($('#http_auth').val()) {
        sData += " -a " + $('#http_auth').val();
    }

	if ($('#group').val()) {
        sData += " -g " + $('#group').val();
    }

    if ($('#rewrite_host').prop("checked")) {
        sData += " -R";
    }

    if (dec_pos != 0) {
        sData += " -D " + dec_pos;
    }

    if ($('#http_visit').prop("checked")) {
        sData += " -H";
    }

    if ($('#ssl_visit').prop("checked")) {
        sData += " -S";
    }

    if ($('#bypass_door').prop("checked")) {
        sData += " -B";
    }

    if ($('#self_domain').val()) {
        sData += " -s " + $('#self_domain').val();
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


