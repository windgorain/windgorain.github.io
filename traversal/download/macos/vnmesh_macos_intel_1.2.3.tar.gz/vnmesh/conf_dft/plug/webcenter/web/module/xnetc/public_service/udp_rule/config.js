function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;xnetc-view;public-service udp "+ $("#name").val();

	if ($('#tname').val() == "") {
        sData += " localhost:" + $('#port').val();
    } else {
        sData += " " + $('#tname').val() + ":" + $('#port').val();
    }

    sData += " -e";

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


