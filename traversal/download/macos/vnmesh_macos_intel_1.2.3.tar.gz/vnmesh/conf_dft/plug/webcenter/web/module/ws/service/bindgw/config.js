function MySubmit(list_name) {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;ws-view;service " + list_name + ";bind gateway " + $("#Gateway").val();

    if ($("#VHost").val() != "") {
        sData += " vhost " + $("#VHost").val();
    }

    if ($("#Domain").val() != "") {
        sData += " domain " + $("#Domain").val();
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}
