function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;acl-view;ip-acl " + $("#name").val();

    sData += ";default action " + $('input:radio[name=dft_action]:checked').val();
    sData += ";work-mode " + $('#work_mode').val();

    var str = $('#description').val();
    if (str != "") {
        sData += ";description \"" + str + "\"";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

