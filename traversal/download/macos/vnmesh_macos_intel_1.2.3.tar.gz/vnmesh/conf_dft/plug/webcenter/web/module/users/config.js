function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var name = $("#name").val();

    var sData = "_do=cmd.run&cmd=config-view;users-view";

    var passwd = $("#passwd").val();
    if (passwd) {
        sData += ";user " + name + " password " + passwd;
    }

    var group = $("#group").val();
    if (group) {
        sData += ";user " + name + " group " + group;
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


