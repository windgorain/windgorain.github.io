function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var cmds = ";type " + $('input:radio[name=Type]:checked').val();

    if ($("#Description").val() != "") {
        cmds += ";description " + $("#Description").val();
    } else {
        cmds += ";no description"
    }
    if ($("#Port").val() != "") {
        cmds += ";port " + $("#Port").val();
    }
    if ($("#IpAddress").val() != "") {
        cmds += ";ip address " + $("#IpAddress").val();
    } else {
        cmds += ";ip address 0.0.0.0";
    }
    if ($('#Enable').prop("checked")) {
        cmds += ";service enable";
    } else {
        cmds += ";no service enable";
    }

    var sData = "_do=cmd.run&cmd=config-view;ws-view;gateway " + $("#name").val() + cmds;
	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

