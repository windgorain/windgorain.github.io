function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var vs = "tcp:" + $("#vs").val();

    var sData = "_do=cmd.run&cmd=config-view;port-mapping-view;rule " + vs + " rs " + $("#rs_addr").val() + " " + $("#rs_port").val();

	if ($('#enable').prop("checked")) {
        sData += ";rule " + vs + " enable";
    } else {
        sData += ";no rule " + vs + " enable";
    }

    var id = $('#nathole_id').val();
    if (id == "") {
        sData += ";no rule " + vs + " id";
    } else {
        sData += ";rule " + vs + " id " + id;
    }

	if ($('#nathole').prop("checked")) {
        sData += ";rule " + vs + " nathole";
    } else {
        sData += ";no rule " + vs + " nathole";
    }

    var desc = $('#desc').val();
    if (desc == "") {
        sData += ";no rule " + vs + " description";
    } else {
        sData += ";rule " + vs + " description " + desc;
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

