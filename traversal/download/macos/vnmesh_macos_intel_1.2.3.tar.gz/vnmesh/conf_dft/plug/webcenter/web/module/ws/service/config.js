function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var cmds = "";

    if ($("#Description").val() != "") {
        cmds += ";description " + $("#Description").val();
    } else {
        cmds += ";no description";
    }
    if ($('#Enable').prop("checked")) {
        cmds += ";service enable";
    } else {
        cmds += ";no service enable";
    }

    var sData = "_do=cmd.run&cmd=config-view;ws-view;service " + $("#name").val() + cmds;

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

