function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;xnetc-view;bookmark " + $("#bookmark_name").val() + " " + $("#bookmark_content").val();

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


