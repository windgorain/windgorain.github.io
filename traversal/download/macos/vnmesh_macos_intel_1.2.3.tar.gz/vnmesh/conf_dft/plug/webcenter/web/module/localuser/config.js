function compare_password() {
	if ($("#password1").val() != $("#password2").val()) {
		return "密码不一致";
	}

	return null;
}

function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;localuser-view;local-user " + $("#name").val();

    if ($("#Description").val() == "") {
        sData += ";no description";
    } else {
        sData += ";description " + $("#Description").val();
    }

    if ($("#password1").val() != "") {
        sData += ";password simple " + $("#password1").val();
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}
