vnmesh -c
