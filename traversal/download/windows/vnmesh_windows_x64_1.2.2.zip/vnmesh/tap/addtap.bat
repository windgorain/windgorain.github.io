rem Add a new TAP virtual ethernet adapter
tap\tapinstall.exe install tap\OemVista.inf tap0901
pause
