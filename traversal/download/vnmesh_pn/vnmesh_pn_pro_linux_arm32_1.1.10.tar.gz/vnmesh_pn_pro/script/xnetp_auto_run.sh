IF=eth0 #关联的网络接口, 您可以根据情况修改为其它接口

#加载设备映射模块
sudo ./klctool load spf spf/kapp/xnetp_fwd_spf.spf -r

#卸载MGW
cd mgw
sudo ./mgwtool detach xdp -t ${IF} > /dev/null 2>&1
sudo ./mgwtool unload all-instance > /dev/null 2>&1
cd ..

#加载MGW
cd mgw

sudo ./mgwtool load ins -n ttriode -f traffic/xdp_ttriode_traffic_klc.o
sudo ./mgwtool load ins -n triode -f traffic/xdp_triode_traffic_klc.o
sudo ./mgwtool load ins -n sys_acl -f leaf/xdp_ip_acl_leaf_kern.o
sudo ./mgwtool load ins -n map_acl -f leaf/xdp_ip_acl_leaf_kern.o
sudo ./mgwtool load ins -n xdpevent -f leaf/xdp_event_leaf_klc.o

sudo ./mgwtool attach instance -n map_acl -t triode -s 0 #绑定map_acl到triode的0槽位
sudo ./mgwtool attach instance -n xdpevent -t triode -s 1  #绑定xdpevent到triode的1槽位
sudo ./mgwtool attach instance -n triode -t ttriode -s 0 #绑定triode到ttriode的0槽位
sudo ./mgwtool attach instance -n sys_acl -t ttriode -s 1 #绑定系统sys_acl到ttriode的1槽位
sudo ./mgwtool attach xdp -n ttriode -t ${IF}  #绑定ttriode到${IF}网络接口

echo ""
echo "mgw instances:"
sudo ./mgwtool tree instance

#配置map_acl, 用于设备映射过滤规则
sudo ./leaf/mgw-acl add -n map_acl -a drop -t 1   #icmp报文禁止映射到内网设备
sudo ./leaf/mgw-acl add -n map_acl -a drop -t tcp --dport 22  #22端口禁止映射到内网设备, 默认送给本机, 用户如果需要映射到内网可以自行修改
sudo ./leaf/mgw-acl default pass -n map_acl #默认其它情况, 映射到内网设备

echo ""
echo "map_acl rules:"
sudo ./leaf/mgw-acl show rule -n map_acl

#配置sys_acl, 允许哪些报文进入Linux Kernel
#sudo ./leaf/mgw-acl add -n sys_acl -a pass -t tcp --dport 2 #允许ssh访问linux
#sudo ./leaf/mgw-acl default drop -n sys_acl #默认禁止所有报文访问linux
sudo ./leaf/mgw-acl default pass -n sys_acl #默认允许所有报文访问linux

echo ""
echo "sys_acl rules:"
sudo ./leaf/mgw-acl show rule -n sys_acl

sudo ./mgwtool enable all

cd .. 

