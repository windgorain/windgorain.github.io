#关联的网络接口
IF=eth0

#卸载mgw
cd mgw
sudo ./mgwtool unload ins -n ttriode > /dev/null 2>&1
sudo ./mgwtool unload ins -n xdpevent > /dev/null 2>&1
sudo ./mgwtool unload ins -n acl > /dev/null 2>&1
cd ..

#卸载KLC
cd klc
./unloadspf.sh
cd ..

#加载KLC
cd klc
./loadspf.sh
sudo ./klctool load spf ../spf/kapp/blind_insn.spf -r
sudo ./klctool load spf ../spf/kapp/xnetp_fwd_spf.spf -r
cd ..

#加载MGW
cd mgw

sudo ./mgwtool load ins -n ttriode -f traffic/xdp_ttriode_traffic_kern.o
sudo ./mgwtool attach xdp -n ttriode -t ${IF}

sudo ./mgwtool load ins -n xdpevent -f leaf/xdp_event_leaf_klc.o
sudo ./mgwtool attach instance -n xdpevent -t ttriode -s 0

sudo ./mgwtool load ins -n acl -f leaf/xdp_ip_acl_leaf_kern.o
sudo ./mgwtool attach instance -n acl -t ttriode -s 1

sudo ./mgwtool tree instance

#配置ACL: 允许这些端口进入Linux
sudo ./leaf/mgw-acl default drop -n acl
sudo ./leaf/mgw-acl add -n acl -a pass -t 1
sudo ./leaf/mgw-acl add -n acl --action pass --protocol tcp --dport 2
sudo ./leaf/mgw-acl add -n acl --action pass --protocol tcp --dport 22
sudo ./leaf/mgw-acl add -n acl --action pass --protocol tcp --dport 80
sudo ./leaf/mgw-acl add -n acl --action pass --protocol tcp --dport 443
sudo ./leaf/mgw-acl add -n acl --action pass --protocol tcp --dport 1024-65535
sudo ./leaf/mgw-acl add -n acl --action pass --protocol udp --dport 1024-65535
sudo ./leaf/mgw-acl show rule -n acl

sudo ./mgwtool enable all

cd ..

