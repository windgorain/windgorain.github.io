function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;port-mapping-view;rule " + $("#vs").val() + " rs " + $("#rs_addr").val() + " " + $("#rs_port").val();

	if ($('#enable').prop("checked")) {
        sData += ";rule " + $("#vs").val() + " enable";
    } else {
        sData += ";no rule " + $("#vs").val() + " enable";
    }

	if ($('#nathole').prop("checked")) {
        sData += ";rule " + $("#vs").val() + " nathole";
    } else {
        sData += ";no rule " + $("#vs").val() + " nathole";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

