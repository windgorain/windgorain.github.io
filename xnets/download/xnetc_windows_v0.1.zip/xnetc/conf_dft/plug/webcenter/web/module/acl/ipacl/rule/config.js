function MySubmit(list_name) {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;acl-view;ip-acl " + list_name;

    sData += ";rule " + $('#rule_id').val() + " " + $('input:radio[name=action]:checked').val();

    var protocol = $('#protocol').val();
    if (protocol != "") {
        sData += " -t " + protocol;
    }

    var ip = $('#sip').val();
    if (ip != "") {
        sData += " -s " + ip;
    }

    ip = $('#dip').val();
    if (ip != "") {
        sData += " -d " + ip;
    }

    port = $('#sport').val();
    if (port != "") {
        sData += " -p " + port;
    }

    port = $('#dport').val();
    if (port != "") {
        sData += " -o " + port;
    }

    str = $('#information').val();
    if (str != "") {
        sData += " -i \"" + str + "\"";
    }

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}

