function MySubmit() {
	var oForm = document.getElementById("MyForm");
	if (CType_CheckForm(oForm) == false) {
		return false;
	}

    var sData = "_do=cmd.run&cmd=config-view;xnetc-view;public-service " + $("#port").val() + " " + $("#description").val();

	if (! RQ_Post("/request.cgi", sData)) {
        return false;
    }

	return true;
}


