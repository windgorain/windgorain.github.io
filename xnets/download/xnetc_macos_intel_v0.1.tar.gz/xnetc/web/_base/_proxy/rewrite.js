var g_my1 = !1
  , g_my2 = !1
  , g_my3 = !1
  , g_my4 = ""
  , g_my5 = 5
  , g_my6 = "/_proxy_/"
  , g_my7 = "http"
  , g_my8 = "https"
  , g_my9 = "80"
  , g_my10 = "443";
function s_r_trim(a) {
    return a.replace(/^([\s]*)/, "")
}
function s_r_htmlcode(a) {
    var b = "";
    if (!a)
        return a;
    var e = typeof a;
    if ("string" != e)
        if ("object" == e && "" != a.toString)
            a = a.toString();
        else
            return a;
    if (a && a.length)
        for (a = a.replace(/</g, "~~<"),
        a = a.replace(/>/g, ">~~"),
        a = a.split("~~"),
        e = 0; e < a.length; e++) {
            var d = a[e];
            if (d.match(/<[^>]+>/)) {
                var c = d.toLowerCase()
                  , f = "param" == c.substr(1, 5)
                  , m = "meta" == c.substr(1, 4);
                c.substr(1, 8);
                var h = "html" == c.substr(1, 4)
                  , g = "head" == c.substr(1, 4)
                  , l = "body" == c.substr(1, 4)
                  , n = "script" == c.substr(1, 6);
                "style" == c.substr(1, 5) ? g_my1 = !0 : "/style" == c.substr(1, 6) && (g_my1 = !1);
                "script" == c.substr(1, 6) ? g_my2 = !0 : "/script" == c.substr(1, 7) && (g_my2 = !1);
                c = "";
                1 != h && 1 != g && 1 != l && 1 != n || 1 == g_my3 || (c += '<script language="text/javascript" src="/_base/_proxy/rewrite.js">\x3c/script>',
                g_my3 = !0);
                for (; d.length; )
                    if (l = /(\w*\s*=(?!=)\s*'[^']*'|\w*\s*=(?!=)\s*"[^"]*"|\w*\s*=(?!=)\s*[^\s>]+)/,
                    (h = d.match(l)) && h.length) {
                        0 < h.index && (c += d.substring(0, h.index));
                        var g = h[0]
                          , d = d.substring(h.index + g.length)
                          , h = ""
                          , l = /^(\w+)(\s*=(?!=)\s*)/
                          , k = g.match(l);
                        k && k.length ? (l = k[1],
                        n = k[2],
                        g = g.substr((l + n).length),
                        (k = g.match(/^'([^']*)'/)) && k.length ? (h = "'",
                        g = k[1]) : (k = g.match(/^"([^"]*)"/)) && k.length && (h = '"',
                        g = k[1]),
                        k = l.toLowerCase(),
                        -1 != k.search(/^(href|src|data|action|archive|codebase|cite|pluginspage|pluginurl|longdesc|classid|background|bgsound|profile|lowsrc|usemap|dynsrc|borderimage)$/) && (g = s_r_url(g)),
                        1 == f && -1 != k.search(/^(value)$/) && (g = s_r_url(g)),
                        "style" == k && (g = s_r_csscode(g)),
                        "on" == k.substr(0, 2) && (g = s_r_jscode(g)),
                        m && "content" == k && (g = s_r_content(g)),
                        c += l + n + h + g + h) : c += g
                    } else
                        c += d,
                        d = "";
                b += c
            } else
                b = 1 == g_my1 ? b + s_r_csscode(d) : 1 == g_my2 ? b + s_r_jscode(d) : b + d
        }
    return b
}
function s_r_write() {
    var a = "", b;
    for (b = 0; b < arguments.length; b++)
        a = "object" == typeof arguments[b] ? a + arguments[b].toString() : a + arguments[b];
    return s_r_htmlcode(a)
}
function s_r_classof(a) {
    return null == a ? "Null" : void 0 == a ? "Undefined" : Object.prototype.toString.call(a).slice(8, -1)
}
function s_r_StrJsCode(a) {
    a && a.length && (a = a.replace(/([a-zA-Z$0-9\._]+)\.writeln\(([^;]*)\)/g, "$1.writeln(s_r_write($2))"),
    a = a.replace(/([a-zA-Z$0-9\._]+)\.write\(([^;]*)\)/g, "$1.write(s_r_write($2))"),
    a = a.replace(/([a-zA-Z$0-9\._]+)\.cookie\s*=(?!=)\s*([^;}]*)([;}]?)/g, "$1.cookie=s_r_cookie($2)$3"),
    a = a.replace(/location\.assign\(([^;]*)\)/g, "location.assign(s_r_url($1))"),
    a = a.replace(/location\.replace\(([^;]*)\)/g, "location.replace(s_r_url($1))"),
    null != a.match(/location\s*=\s*([^;]*)(;?)/) && null == a.match(/\.open\(.+,.+,.*location\s*=.+\)/) && (a = a.replace(/location\s*=(?!=)\s*([^;}]*)([;}]?)/g, "location=s_r_url($1)$2")),
    a = a.replace(/location\.href\s*=(?!=)\s*([^;}]*)([;}]?)/g, "location.href=s_r_url($1)$2"),
    a = a.replace(/window\.open\(([^,]*)(,.*)?\)/g, "window.open(s_r_url($1)$2)"),
    a = a.replace(/\.src\s*=(?!=)\s*([^;}]*)([;}]?)/g, ".src=s_r_url($1)$2"),
    a = a.replace(/\.action\s*=(?!=)\s*([^;}]*)([;}]?)/g, ".action=s_r_url($1)$2"),
    -1 != a.indexOf("innerHTML") || -1 != a.indexOf("outerHTML")) && (a = a.replace(/&#39;/g, "&#39"),
    a = a.replace(/\.innerHTML\s*=(?!=)\s*([^;}]*)([;}]?)/g, ".innerHTML=s_r_htmlcode($1)$2"),
    a = a.replace(/\.outerHTML\s*=(?!=)\s*([^;}]*)([;}]?)/g, ".outerHTML=s_r_htmlcode($1)$2"),
    a = a.replace(/&#39/g, "&#39;"));
    return a
}
function s_r_jscode(a) {
    a && "string" == typeof a && (a = s_r_StrJsCode(a));
    return a
}
function s_r_csscode(a) {
    var b = ""
      , e = /^\s*url\((.*)\)(.*)/i;
    if (!a)
        return a;
    if ("string" != typeof a)
        if ("object" == typeof a && a.toString)
            a = a.toString();
        else
            return a;
    a = a.split(";");
    var d;
    for (d = 0; d < a.length; d++) {
        0 != b.length && (b += ";");
        var c = a[d]
          , f = c.indexOf(":");
        -1 != f ? (b += c.substring(0, f + 1),
        f = c.substring(f + 1),
        c = e.exec(f),
        null != c ? (f = /(['"])([^'"]*)['"]/.exec(c[1]),
        b = null != f && 2 < f.length ? b + ("url(" + f[1] + s_r_url(f[2]) + f[1] + ")" + c[2]) : b + ("url(" + s_r_url(c[1]) + ")" + c[2])) : b += f) : b += a[d]
    }
    return b
}
function s_r_content(a) {
    var b = a.toLowerCase().indexOf("url");
    if (-1 == b)
        return a;
    b = a.indexOf(";");
    if (-1 == b)
        return a;
    var b = a.indexOf("=", b)
      , e = a.substring(0, b + 1);
    a = a.substring(b + 1);
    return e += s_r_url(a)
}
function s_r_url(a) {
    var b, e;
    if (!a)
        return a;
    if ("string" == typeof a)
        b = s_r_trim(a);
    else if ("String" == s_r_classof(a) && "" != a.toString())
        b = a.toString(),
        b = b.replace(/[\s]*([\S]*)[\s]*([\S]*)[\s]*/g, "$1$2");
    else
        return a;
    e = b.match(/(https:\/\/[^\/]+)?\/_base\/_proxy\/rewrite.js/);
    if (null != e)
        return a;
    if (b.includes("/_proxy_/"))
        return a;
    e = b.match(/^[\s]*url\(([^\)]*)\)[\s]*$/);
    if (null != e)
        e[1] = e[1].replace(/^[\s]*['"]([^'"]*)['"][\s]*$/, "$1"),
        e = "url(" + s_r_urlstr(e[1]) + ")";
    else if (e = s_r_urlstr(b),
    e == b && "String" == s_r_classof(a))
        return a;
    return e
}
function s_r_generate_port(a) {
    var b = "0";
    g_my7 == a ? b = g_my9 : g_my8 == a && (b = g_my10);
    return b
}
function s_r_gatewayhostname() {
    var a = window.location.hostname;
    1 == /[:]/g.test(a) && -1 == a.indexOf("[") && (a = "[" + a + "]");
    return a
}
function s_r_fullurl(a) {
    var b, e, d, c, f, m, h = "";
    b = /^(https?):\/\/([^\/]+)\/(.*)/;
    b = b.exec(a);
    null != b && (e = b[1],
    c = b[2],
    m = b[3],
    d = "",
    b = /^([^@]+@)(.*)/,
    b = b.exec(c),
    null != b && (d = b[1],
    c = b[2]),
    f = "0",
    0 == c.indexOf("[") ? (b = c.indexOf("]"),
    f = c.substring(b + 2),
    c = c.substring(0, b + 1)) : (b = /^([^:]+):(\d+)/,
    b = b.exec(c),
    null != b && (c = b[1],
    f = b[2])),
    "0" == f && (f = s_r_generate_port(e)),
    b = /^_proxy_\/https?\/\d+\/.+/,
    1 != b.test(m) ? (a = s_r_gatewayhostname(),
    a == c && (b = /^(https?):\/\/([^\/]+)\/([^\/]+)\/(https?)\/([0-9]+)\/([^\/]+)\/(.*)/,
    b = b.exec(window.location.href),
    null != b && (e = b[4],
    f = b[5],
    c = b[6])),
    h = location.protocol + "//" + a + ":" + location.port,
    h += g_my6 + e + "/" + f + "/" + d + c + "/" + m) : h = a);
    return h
}
function s_r_nopath_fullurl(a) {
    var b, e, d, c, f = "";
    b = /^(https?):\/\/([^\/]+)/;
    b = b.exec(a);
    null != b && (a = b[1],
    d = b[2],
    e = "",
    b = /^([^@]+@)(.*)/,
    b = b.exec(d),
    null != b && (e = b[1],
    d = b[2]),
    c = "0",
    0 == d.indexOf("[") ? (b = d.indexOf("]"),
    c = d.substring(b + 2),
    d = d.substring(0, b + 1)) : (b = /^([^:]+):(\d+)/,
    b = b.exec(d),
    null != b && (d = b[1],
    c = b[2])),
    "0" == c && (c = s_r_generate_port(a)),
    f = s_r_gatewayhostname(),
    f == d && (b = /^(https?):\/\/([^\/]+)\/([^\/]+)\/(https?)\/([0-9]+)\/([^\/]+)\/(.*)/,
    b = b.exec(window.location.href),
    null != b && (a = b[4],
    c = b[5],
    d = b[6])),
    f = location.protocol + "//" + f + ":" + location.port,
    f += g_my6 + a + "/" + c + "/" + e + d + "/");
    return f
}
function s_r_base_root_url(a) {
    var b, e, d = "";
    b = /^\/(.*)/;
    1 == b.test(a) && (b = /^\/_proxy_\/https?\/\d+/,
    1 != /^\/_proxy_\/https?\/\d+\/.+/.test(a) && 1 != b.test(a) && (e = window.location.pathname,
    b = /^(\/_proxy_\/)(https?\/\d+\/[^\/\\]+)\/?/,
    b = b.exec(e),
    null != b && (d = g_my6 + b[2] + a)));
    return d
}
function s_r_base_current_url(a) {
    var b, e = 0, d = "";
    b = /(^\.\.\/)/;
    if (1 == b.test(a)) {
        b = /(((\.\.\/)+)([^\/]*))/g;
        b = a.match(b);
        if (null != b) {
            var c = a;
            for (a = 0; a < b.length - 1 && b[a + 1] == b[0] && 0 == c.indexOf(b[0]); a++)
                c = c.substr(b[0].length + 1);
            a = c
        }
        b = document.location.pathname.match(/[\/]/g);
        null != b && b.length > g_my5 && (e = b.length - g_my5);
        b = /^((\.\.\/)+)(.*)/;
        b = b.exec(a);
        if (null != b && (a = b[1],
        d = b[b.length - 1],
        b = a.match(/\.\.\//g),
        null != b))
            for (b.length < e && (e = b.length); e--; )
                d = "../" + d
    }
    return d
}
function s_r_DecodeUrl(a) {
    a = a.replace(/&#x2F;/g, "/");
    return a = decodeURI(a)
}
function s_r_urlstr(a) {
    var b;
    a = s_r_DecodeUrl(a);
    if (0 == a.indexOf("//")) {
        var e = window.location.pathname;
        b = /^\/_proxy_\/([a-zA-z]*)\/\d\/?/;
        b = b.exec(e);
        a = null != b ? b[1] + ":" + a : "http:" + a
    }
    b = /^httpss+:\/\/(.*)/;
    b = b.exec(a);
    null != b && (a = "https://" + b[1],
    b = /^(https:\/\/[^\/]+)\/http\/([0-9]+\/.*)/,
    b = b.exec(a),
    null != b && (a = b[1] + "/_proxy_//https/" + b[2]));
    b = s_r_fullurl(a);
    if ("" != b)
        return b;
    b = s_r_nopath_fullurl(a);
    if ("" != b)
        return b;
    b = s_r_base_root_url(a);
    if ("" != b)
        return b;
    b = s_r_base_current_url(a);
    "" == b && (b = a);
    return b
}
function s_r_cookie(a) {
    var b, e, d, c = "", f = !1;
    if (a && a.length && "string" == typeof a) {
        a = a.split(";");
        for (d = 0; d < a.length; d++)
            if (e = a[d].indexOf("="),
            -1 != e) {
                b = a[d].substring(0, e);
                e = a[d].substring(e + 1);
                b = s_r_trim(b);
                e = s_r_trim(e);
                if ("path" == b.toLowerCase())
                    e = s_r_urlstr(e);
                else if ("domain" == b.toLowerCase())
                    continue;
                c = 0 == d ? c + (b + "=" + e) : c + ("; " + b + "=" + e)
            } else
                "secure" == a[d].toLowerCase() && (f = !0),
                c = 0 == d ? c + a[d] : c + ("; " + a[d]);
        1 != f && (c += "; secure")
    } else
        c = a;
    return c
}
function s_r_ajax(a) {
    if (!a || "object" != typeof a || "undefined" == a.url)
        return a;
    a.url = s_r_url(a.url);
    return a
}
function s_r_attr(a) {
    var b;
    if (!a)
        return a;
    if ("object" == typeof a) {
        for (b in a)
            ("href" == b || "src" == b || "action" == b || "archive" == b || "codebase" == b || "cite" == b || "background" == b || "bgsound" == b || "profile" == b || "lowsrc" == b || "usemap" == b || "dynsrc" == b || "data" == b || "borderimage" == b || "classid" == b || "longdesc" == b || "pluginspage" == b || "pluginurl" == b) && a[b] && (a[b] = s_r_url(a[b]));
        return a
    }
    "string" == typeof a && (g_my4 = a);
    return a
}
function s_r_attrvalue(a) {
    if (!a || "string" != typeof a)
        return a;
    if ("href" == g_my4 || "src" == g_my4 || "action" == g_my4 || "archive" == g_my4 || "codebase" == g_my4 || "cite" == g_my4 || "background" == g_my4 || "bgsound" == g_my4 || "profile" == g_my4 || "lowsrc" == g_my4 || "usemap" == g_my4 || "dynsrc" == g_my4 || "data" == g_my4 || "borderimage" == g_my4 || "classid" == g_my4 || "longdesc" == g_my4 || "pluginspage" == g_my4 || "pluginurl" == g_my4)
        a = s_r_url(a);
    g_my4 = "";
    return a
}

(function() {
  const origOpen = XMLHttpRequest.prototype.open;

  XMLHttpRequest.prototype.open = function(method, url) {
    if (url.includes("/_proxy_/")) {
      this._url = url;
      return origOpen.apply(this, arguments);
    } else {
      this._url = s_r_fullurl(url);
      return origOpen.apply(this, arguments);
    }
  };
})();


